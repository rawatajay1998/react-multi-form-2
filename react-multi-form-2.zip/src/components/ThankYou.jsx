import React from "react";

const ThankYou = () => {
  return (
    <div className="wrapper">
      <h2>Thank You</h2>
    </div>
  );
};

export default ThankYou;
